"""Model training utilities."""
import joblib
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

MODELS_DIR = Path(__file__).resolve().parents[2] / "models"

def split_data(X, y, test_size=0.2, random_state=42):
    return train_test_split(X, y, test_size=test_size, random_state=random_state)

def train_model(model, X_train, y_train):
    model.fit(X_train, y_train)
    return model

def evaluate_classification(model, X_test, y_test):
    y_pred = model.predict(X_test)
    print(classification_report(y_test, y_pred))
    return y_pred

def save_model(model, filename: str):
    joblib.dump(model, MODELS_DIR / filename)
    print(f"Model saved: {filename}")

def load_model(filename: str):
    return joblib.load(MODELS_DIR / filename)
