"""Data loading utilities."""
import pandas as pd
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parents[2] / "data"

def load_raw_data(filename: str) -> pd.DataFrame:
    """Load raw data from the data/raw directory."""
    return pd.read_csv(DATA_DIR / "raw" / filename)

def save_processed_data(df: pd.DataFrame, filename: str) -> None:
    """Save processed data to the data/processed directory."""
    filepath = DATA_DIR / "processed" / filename
    df.to_csv(filepath, index=False)
    print(f"Saved to {filepath}")
