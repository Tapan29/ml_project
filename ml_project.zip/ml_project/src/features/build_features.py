"""Feature engineering utilities."""
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder

def encode_categoricals(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    df = df.copy()
    le = LabelEncoder()
    for col in columns:
        df[col] = le.fit_transform(df[col].astype(str))
    return df

def scale_features(df: pd.DataFrame, columns: list):
    df = df.copy()
    scaler = StandardScaler()
    df[columns] = scaler.fit_transform(df[columns])
    return df, scaler
