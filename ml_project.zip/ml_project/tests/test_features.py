"""Unit tests for feature engineering."""
import pytest
import pandas as pd
import numpy as np
from src.features.build_features import encode_categoricals, scale_features

def test_encode_categoricals():
    df = pd.DataFrame({"color": ["red", "blue", "green"]})
    result = encode_categoricals(df, ["color"])
    assert result["color"].dtype in [int, np.int64, np.int32]

def test_scale_features():
    df = pd.DataFrame({"age": [20.0, 30.0, 40.0], "salary": [30000.0, 50000.0, 70000.0]})
    result, scaler = scale_features(df, ["age", "salary"])
    assert abs(result["age"].mean()) < 1e-10
