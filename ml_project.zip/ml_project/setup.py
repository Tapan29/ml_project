from setuptools import find_packages, setup

setup(
    name='ml_project',
    packages=find_packages(),
    version='0.1.0',
    description='A Machine Learning Project',
    author='Your Name',
    license='MIT',
)
